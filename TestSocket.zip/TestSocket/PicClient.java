import java.net.Socket;
import java.io.*;

public class PicClient {
	// main
	public static void main(String[] args) throws Exception {
		Socket socket = new Socket("127.0.0.1", 5000);
		
		byte[] buf = new byte[1024];
		int len = -1;
		FileInputStream fileInputStream = new FileInputStream("pic.jpg");
		OutputStream outputStream = socket.getOutputStream();
		while ( (len = fileInputStream.read(buf)) != -1 ) {
			outputStream.write(buf, 0, len);
		}
		
		outputStream.close();
		fileInputStream.close();
		socket.close();
	}
	
	// static code block
	static {
		System.out.println("-----------------------------------");
		System.out.println("The client is online!");
		System.out.println("-----------------------------------");
	}
}