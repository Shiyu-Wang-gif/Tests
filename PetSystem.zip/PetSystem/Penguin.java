// package petSystem;

public class Penguin extends Pet {
	// field
	private String gender;
	
	public static final String GENDER_MALE = "Q��";
	public static final String GENDER_FEMALE = "Q��";
	
	// constructor
	public Penguin() {
		// super();
	}
	
	public Penguin(String name, int health, int intimacy, String gender) {
		super(name, health, intimacy);
		this.gender = gender;
	}
	
	// setter and getter	
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getGender() {
		return this.gender;
	}
	
	// method
	public void printField() {
		System.out.println("The penguin's information:");
		super.printField();
		System.out.println("gender: " + this.gender);
	}
	
	// main
	
	// static code block
}