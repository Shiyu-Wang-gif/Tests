import java.io.*;

public class User implements Serializable {
	// field
	private String userName;
	private String password;
	
	// constructor
	public User() {
		
	}
	
	public User(String userName, String password) {
		this.userName = userName;
		this.password = password;
	}
	
	// setter and getter
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getUserName() {
		return this.userName;
	}
	
	public String getPassword() {
		return this.password;
	}
	
	// method
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		
		if (obj instanceof User) {
			User userObj = (User)obj;
			if ( (userObj.userName.equals(this.userName)) && (userObj.password.equals(this.password)) ) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
	
	@Override
	public String toString() {
		return "user name: " + this.userName + " ----- password: " + this.password;
	}
}