public class FamilyCar extends Car {
	// field
	private String owner;
	
	// constructor
	public FamilyCar() {
		// super();
	}
	
	public FamilyCar(String type, String licenseNumber, String owner) {
		super(type, licenseNumber);
		this.owner = owner;
	}
	
	// setter and getter
	public void setOwner(String owner) {
		this.owner = owner;
	}
	
	public String getOwner() {
		return this.owner;
	}
	
	// method
	public final void start() {
		System.out.println("Let's get out and have fun! My car information is shown below");
		System.out.println("Type: " + super.getType());
		System.out.println("License Number: " + super.getLicenseNumber());
		System.out.println("Owner: " + this.owner);
	}
	
	public final void stop() {
		System.out.println("I'll stop the car");
	}
	
	// static code block
}