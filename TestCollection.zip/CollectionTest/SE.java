import java.util.Objects;

public class SE extends Employee {
	// field
	private int popularity;
	
	// constructor
	public SE() {
		
	}
	
	public SE(int id, String name, int age, Gender gender, int popularity) {
		super(id, name, age, gender);
		this.popularity = popularity;
	}
	
	// setter and getter
	public void setPopularity(int popularity) {
		this.popularity = popularity;
	}
	
	public int getPopularity() {
		return this.popularity;
	}
	
	// method
	@Override
	public String toString() {
		return super.toString() + ", popularity " + this.popularity + "\n";
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(super.hashCode(), this.popularity);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		
		if (!super.equals(obj)) {
			return false;
		}
		
		SE se = (SE)obj;
		return this.popularity == se.popularity;
	}
}