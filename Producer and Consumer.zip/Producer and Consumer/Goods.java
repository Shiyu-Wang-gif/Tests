public class Goods {
	// field
	private String brand;
	private String product;
	private boolean stock = false;
	
	// constructor
	public Goods() {
		
	}
	
	public Goods(String brand, String product) {
		this.brand = brand;
		this.product = product;
	}
	
	// setter and getter
	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	public void setProduct(String product) {
		this.product = product;
	}
	
	public void setStock(boolean stock) {
		this.stock = stock;
	}
	
	public String getBrand() {
		return this.brand;
	}
	
	public String getProduct() {
		return this.product;
	}
	
	public boolean getStock() {
		return this.stock;
	}
	
	// method
	public synchronized void produce(String brand, String product) {
		if (this.stock) {
			try {
				wait();
			} catch (InterruptedException interEx) {
				interEx.printStackTrace();
			}
		}
		
		this.brand = brand;
		this.product = product;
		System.out.println(Thread.currentThread().getName() + " produces " + this.brand + "---" + this.product);
		this.stock = true;
		notify();
	}
	
	public synchronized void consume() {
		if (!this.stock) {
			try {
				wait();
			} catch (InterruptedException interEx) {
				interEx.printStackTrace();
			}
		}
		
		System.out.print(Thread.currentThread().getName() + " consumes " + this.brand);
		System.out.println("======" + this.product);
		this.stock = false;
		notify();
	}
}