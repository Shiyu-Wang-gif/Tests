public class TestMonster {
	// main
	public static void main(String[] args) {
		Snake snake1 = new Snake("little snake", 5, 30);
		snake1.attacking();
		snake1.move();
		snake1.addHealth();
		System.out.println("=====================================");
		
		Centipede centipede1 = new Centipede("super centipede", 100, 200);
		centipede1.attacking();
		centipede1.move();
	}
	
	// static code block
	static {
		System.out.println("Test inheritance of the Monster class");
		System.out.println("=====================================");
	}
}