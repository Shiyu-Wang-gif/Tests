// package petSystem;

public class Pet {
	// field
	private String name;
	private int health;
	private int intimacy;
	
	// constructor
	public Pet() {
		
	}
	
	public Pet(String name, int health, int intimacy) {
		this.name = name;
		this.health = health;
		this.intimacy = intimacy;
	}
	
	// setter and getter
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setHealth(int health) {
		if (health > 0) {
			this.health = health;
		}
		else {
			System.out.println("Invalid input");
		}
	}
	
	public int getHealth() {
		return this.health;
	}
	
	public void setIntimacy(int intimacy) {
		if (intimacy >= 0) {
			this.intimacy = intimacy;
		}
		else {
			System.out.println("Invalid input");
		}
	}
	
	public int getIntimacy() {
		return this.intimacy;
	}
	
	// method
	public void printField() {
		System.out.println("Name: " + this.name + "\nHealth: " + this.health + "\nIntimacy: " + this.intimacy);
	}
}