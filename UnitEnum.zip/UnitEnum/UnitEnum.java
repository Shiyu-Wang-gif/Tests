public enum UnitEnum {
	// element
	U1("junior"), U2("senior"), U3("advanced");
	
	// field
	private String goal;
	
	// constructor
	UnitEnum() {
		
	}
	
	UnitEnum(String goal) {
		this.goal = goal;
	}
	
	// setter and getter
	public void setGoal(String goal) {
		this.goal = goal;
	}
	
	public String getGoal() {
		return this.goal;
	}
	
	// method
	public void show() {
		System.out.println(super.name() + ": " + this.goal);
	}
}