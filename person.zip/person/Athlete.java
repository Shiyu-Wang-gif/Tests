public class Athlete extends Person {
	// field
	private String program;
	private String record;
	
	// constructor
	public Athlete() {
		// super();
	}
	
	public Athlete(String name, int age, String gender, String program, String record) {
		super(name, age, gender);
		this.program = program;
		this.record = record;
	}
	
	// setter and getter
	public void setProgram(String program) {
		this.program = program;
	}
	
	public void setRecord(String record) {
		this.record = record;
	}
	
	// method
	@Override
	public void selfIntroduction() {
		super.selfIntroduction();
		System.out.println("I'm good at " + this.program);
		System.out.println("The program record is " + this.record);
	}
	
	// static code block
}