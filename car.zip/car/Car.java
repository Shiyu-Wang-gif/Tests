public abstract class Car {
	// field
	private String type;
	private String licenseNumber;
	
	// constructor
	public Car() {
		
	}
	
	public Car(String type, String licenseNumber) {
		this.type = type;
		this.licenseNumber = licenseNumber;
	}
	
	// setter and getter
	public void setType(String type) {
		this.type = type;
	}
	
	public void setLicenseNumber(String licenseNumber) {
		this.licenseNumber = licenseNumber;
	}
	
	public String getType() {
		return this.type;
	}
	
	public String getLicenseNumber() {
		return this.licenseNumber;
	}
	
	// method
	public abstract void start();
	
	public abstract void stop();
	
	// static code block
}