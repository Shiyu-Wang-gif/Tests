public final class TaxiCar extends Car {
	// field
	private String company;
	
	// constructor
	public TaxiCar() {
		// super();
	}
	
	public TaxiCar(String type, String licenseNumber, String company) {
		super(type, licenseNumber);
		this.company = company;
	}
	
	// setter and getter
	public void setCompany(String company) {
		this.company = company;
	}
	
	public String getCompany() {
		return this.company;
	}
	
	// method
	public void start() {
		System.out.println("Hello passenger, my taxi information is shown below");
		System.out.println("Type: " + super.getType());
		System.out.println("License number: " + super.getLicenseNumber());
		System.out.println("Company: " + this.company);
	}
	
	public void stop() {
		System.out.println("We have arrived the destination, hava a good day!");
	}
	
	// static code block
}