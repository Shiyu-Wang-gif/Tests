public class TestUnitEnum {
	// main
	public static void main(String[] args) {
		UnitEnum[] unitEnumArr = UnitEnum.values();
		for (int i = 0; i < unitEnumArr.length; i++) {
			unitEnumArr[i].show();
		}
	}
	
	// static code block
	static {
		System.out.println("Test the UnitEnum enumeration");
	}
} 