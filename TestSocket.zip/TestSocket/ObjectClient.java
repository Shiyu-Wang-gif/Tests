import java.net.Socket;
import java.io.*;
import java.util.Scanner;

public class ObjectClient {
	// main
	public static void main(String[] args) throws Exception {
		// create socket and streams
		User user = new User();
		boolean flag = false;
		
		Scanner scanner = new Scanner(System.in);
		while (!flag) {
			Socket socket = new Socket("127.0.0.1", 5000);
		
			OutputStream outputStream = socket.getOutputStream();
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
		
			InputStream inputStream = socket.getInputStream();
			DataInputStream dataInputStream = new DataInputStream(inputStream);
		
			// login process
			System.out.print("User name: ");
			user.setUserName(scanner.next());
			System.out.print("Password: ");
			user.setPassword(scanner.next());
			// System.out.println(user.toString());
		
			objectOutputStream.writeObject(user);
			
			flag = dataInputStream.readBoolean();
			if (flag) {
				System.out.println("Login successful!");
			} else {
				System.out.println("Incorrect user name or password!");
			}
			System.out.println();
			socket.shutdownOutput();
			socket.shutdownInput();
		
			// close streams
			dataInputStream.close();
			inputStream.close();
			objectOutputStream.close();
			outputStream.close();
			socket.close();
		}
	}
	
	// static code block
	static {
		System.out.println("============================");
		System.out.println("The client is online!");
		System.out.println("============================");
	}
}