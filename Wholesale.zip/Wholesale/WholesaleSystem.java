import java.util.Scanner;

public class WholesaleSystem {
	// method
	public static void login() {
		Scanner sc = new Scanner(System.in);
		UserInfo userInfo = new UserInfo("Shiyu", "shiyuwang");
		String userName, password;
		do {
			System.out.print("User name: ");
			userName = sc.next();
			System.out.print("Password: ");
			password = sc.next();
			System.out.println("=============================================");
		} while (!userInfo.loginCheck(userName, password));
		System.out.println("Login succeed!");
	}
	
	public static void buy() {
		Goods[] goodsArray = new Goods[5];
		goodsArray[0] = new Goods("Fan", 124.23);
		goodsArray[1] = new Goods("Washing Machine", 4500.0);
		goodsArray[2] = new Goods("TV", 8800.9);
		goodsArray[3] = new Goods("Refrigerator", 5000.88);
		goodsArray[4] = new Goods("Air Conditioner", 4456.0);
		
		StringBuffer stringBuffer = new StringBuffer();
		System.out.println("=============   Goods List   ================");
		for (int i = 0; i < goodsArray.length; i++) {
			stringBuffer.delete(0, stringBuffer.length());
			stringBuffer.append("     ").append(i+1).append("     ").append(goodsArray[i].show());
			System.out.println(stringBuffer);
		}
		System.out.println("=============================================");
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Serial number: ");
		int serialNum = sc.nextInt();
		System.out.print("Quantity: ");
		int qty = sc.nextInt();
		System.out.print("Total due: ");
		System.out.println(goodsArray[serialNum-1].totalDue(qty));
	}
	
	// main
	public static void main(String[] args) {
		login();
		buy();
	}
	
	// static code block
	static {
		System.out.println("=============================================");
		System.out.println("Welcome to the Wholesale System");
		System.out.println("=============================================");
	}
}