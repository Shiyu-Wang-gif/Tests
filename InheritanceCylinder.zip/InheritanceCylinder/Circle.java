public class Circle {
	// field
	private double radius;
	
	// constructor
	public Circle() {
		System.out.println("I'm the constructor without arguments in the Circle class");
	}
	
	public Circle(double radius) {
		this.radius = radius;
	}
	
	// setter and getter
	public void setRadius(double radius) {
		this.radius = radius;
	}
	
	public double getRadius() {
		return this.radius;
	}
	
	// method
	public double area() {
		return Math.PI * this.radius * this.radius;
	}
	
	public double perimeter() {
		return 2 * Math.PI * this.radius;
	}
	
	public void showProperties() {
		System.out.println("Radius: " + this.radius);
		System.out.println("Area: " + this.area());
		System.out.println("Periemter: " + this.perimeter());
	}
	
	// static code block
	static {
		System.out.println("Static code blcok in the Circle class");
	}
}