import java.util.Comparator;

public class Sorter<T> {
    // field
    private T[] array;
    private Comparator<T> comparator;

    // constructor
    public Sorter(T[] array, Comparator<T> comparator) {
        this.array = array;
        this.comparator = comparator;
    }

    // setter and getter
    public void setArray(T[] array) {
        this.array = array;
    }

    public void setComparator(Comparator<T> comparator) {
        this.comparator = comparator;
    }

    // method
    public void sort() {
        int minIndex;
        T minValue;
        for (int i = 0; i < this.array.length - 1; i++) {
            minIndex = i;
            minValue = this.array[i];
            for (int j = i + 1; j < this.array.length; j++) {
                if (this.comparator.compare(this.array[j], minValue) < 0) {
                    minIndex = j;
                    minValue = this.array[j];
                }
            }
            this.swap(i, minIndex);
        }
    }

    private void swap(int i, int j) {
        T temp = this.array[i];
        this.array[i] = this.array[j];
        this.array[j] = temp;
    }

    public void show() {
        for (int i = 0; i < this.array.length; i++) {
            System.out.print(this.array[i] + " ");
        }
        System.out.println();
    }
}
