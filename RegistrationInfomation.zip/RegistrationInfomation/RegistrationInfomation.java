public class RegistrationInfomation {
	// field
	private String userName;
	private String password;
	private String passwordConfirmation;
	
	public static final int userNameLimit = 3;
	public static final int passwordLimit = 6;
	
	// constructor
	public RegistrationInfomation() {
		
	}
	
	public RegistrationInfomation(String userName, String password, String passwordConfirmation) {
		this.userName = userName;
		this.password = password;
		this.passwordConfirmation = passwordConfirmation;
	}
	
	// setter and getter
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setPasswordConfirmation(String passwordConfirmation) {
		this.passwordConfirmation = passwordConfirmation;
	}
	
	public String getUserName() {
		return this.userName;
	}
	
	public String getPassword() {
		return this.password;
	}
	
	public String getPasswordConfirmation() {
		return this.passwordConfirmation;
	}
	
	// method
	public boolean verify() {
		boolean flag = true;
		String warningInfo = new String();
		
		if (this.userName.length() < this.userNameLimit) {
			flag = false;
			warningInfo = warningInfo.concat("The length of user name should be longer than " + this.userNameLimit);
		}
		
		if (this.password.length() < this.passwordLimit) {
			flag = false;
			warningInfo = warningInfo.concat(", and the length of password shoud be longer than " + this.passwordLimit);
		}
		
		if (!password.equals(passwordConfirmation)) {
			flag = false;
			warningInfo = warningInfo.concat(", and the password confirmation is not the same as the password");
		}
		
		if (!flag) {
			if (warningInfo.startsWith(", and")) {
				warningInfo = Character.toUpperCase(warningInfo.charAt(6)) + warningInfo.substring(7);
			}
			System.out.println(warningInfo + ".");
		}
		
		return flag;
	}
}