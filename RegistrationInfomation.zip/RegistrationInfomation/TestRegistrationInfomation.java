import java.util.Scanner;

public class TestRegistrationInfomation {
	// main 
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		RegistrationInfomation ri = new RegistrationInfomation();
		
		do {
			System.out.println("==============================================");
			System.out.print("User name: ");
			ri.setUserName(sc.next());
			System.out.print("Password: ");
			ri.setPassword(sc.next());
			System.out.print("Confirm your password: ");
			ri.setPasswordConfirmation(sc.next());
		} while (!ri.verify());
		
		System.out.println("Registration succeed!");
	}
	
	// static code block
	static {
		System.out.println("==============================================");
		System.out.println("User Registration");
		System.out.println("==============================================");
	}
}