public class Cat{
    // field
    private final int weight;
    private final int height;

    // constructor
    public Cat(int weight, int height) {
        this.weight = weight;
        this.height = height;
    }

    // setter and getter
    public int getWeight() {
        return this.weight;
    }

    // method

    @Override
    public String toString() {
        return "Cat{" +
                "weight=" + weight +
                ", height=" + height +
                '}';
    }
}
