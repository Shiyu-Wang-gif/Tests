public class TestCylinder {
	// main
	public static void main(String[] args) {
		Cylinder cylinder1 = new Cylinder(2, 3);
		cylinder1.showProperties();
	}
	
	// static code block
	static {
		System.out.println("Static code block for the main function");
	}
}