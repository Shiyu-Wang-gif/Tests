import java.net.Socket;
import java.io.*;

public class BufferedClient {
	// main
	public static void main(String[] args) throws Exception {
		Socket socket = new Socket("127.0.0.1", 5000);
		
		InputStream inputStream = socket.getInputStream();
		InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
		BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
		System.out.println("The client received: " + bufferedReader.readLine());
		socket.shutdownInput();
		
		OutputStream outputStream = socket.getOutputStream();
		OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
		BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
		bufferedWriter.write("I'm your client.");
		bufferedWriter.flush();
		socket.shutdownOutput();
		
		bufferedWriter.close();
		outputStreamWriter.close();
		outputStream.close();
		bufferedReader.close();
		inputStreamReader.close();
		inputStream.close();
		socket.close();
	}
	
	// static code block
	static {
		System.out.println("==============================");
		System.out.println("The Client is online!");
		System.out.println("==============================");
	}
}