public class Test {
	// main
	public static void main(String[] args) {
		Goods goods = new Goods();
		Producer producer = new Producer(goods);
		Consumer consumer = new Consumer(goods);
		
		Thread producerThread = new Thread(producer, "Producer");
		Thread consumerThread = new Thread(consumer, "Consumer");
		
		producerThread.start();
		consumerThread.start();
	}
	
	// static code block
	static {
		System.out.println("======================================");
		System.out.println("Producer and Consumer");
		System.out.println("======================================");
	}
} 