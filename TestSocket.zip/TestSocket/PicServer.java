import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;

public class PicServer {
	// main
	public static void main(String[] args) throws Exception {
		ServerSocket serverSocket = new ServerSocket(5000);
		Socket socket = serverSocket.accept();
		
		byte[] buf = new byte[1024];
		int len = -1;
		InputStream inputStream = socket.getInputStream();
		FileOutputStream fileOutputStream = new FileOutputStream("output.jpg");
		while ( (len = inputStream.read(buf)) != -1 ) {
			fileOutputStream.write(buf, 0, len);
		}
		
		fileOutputStream.close();
		inputStream.close();
		socket.close();
		serverSocket.close();
	}
	
	// static code block
	static {
		System.out.println("=========================================");
		System.out.println("The server is online!");
		System.out.println("=========================================");
	}
}