// package petSystem;

import java.util.Scanner;

public class PetSystem {
	// main
	public static void main(String[] args) {
		Dog dog1 = new Dog();
		dog1.setName("One one");
		dog1.setStrain("Unknown");
		dog1.setHealth(99);
		dog1.printField();
		System.out.println();
		
		Dog dog2 = new Dog("Two two", "Unknown");
		dog2.printField();
		System.out.println();
		
		Penguin penguin1 = new Penguin();
		penguin1.setGender(Penguin.GENDER_FEMALE);
		penguin1.printField();
	}
	
	// static code block
	static {
		System.out.println("Welcome to the pet system!\n");
	}
}