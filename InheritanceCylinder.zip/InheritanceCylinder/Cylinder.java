public class Cylinder extends Circle {
	// field
	private double height;
	
	// constructor
	public Cylinder() {
		// super();
	}
	
	public Cylinder(double height, double radius) {
		super(radius);
		this.height = height;
	}
	
	// setter and getter
	public void setHeight(double height) {
		this.height = height;
	}
	
	public double getHeight() {
		return this.height;
	}
	
	// method
	public double volumn() {
		return super.area() * this.height;
	}
	
	@Override
	public void showProperties() {
		super.showProperties();
		System.out.println("Height: " + this.height);
		System.out.println("Volumn: " + this.volumn());
	}
	
	// static code block
	static {
		System.out.println("Static code block in the Cylinder class");
	}
}