public class Person {
	// field
	private String name;
	private int age;
	private String gender;
	
	// constructor
	public Person() {
		
	}
	
	public Person(String name, int age, String gender) {
		this.name = name;
		this.setAge(age);
		this.gender = gender;
	}
	
	// setter and getter
	public void setName(String name) {
		this.name = name;
	}
	
	public void setAge(int age) {
		if (age >= 0) {
			this.age = age;
		}
		else {
			System.out.println("invalid age input!");
		}
	}
	
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getAge() {
		return this.age;
	}
	
	public String getGender() {
		return this.gender;
	}
	
	// method
	public void selfIntroduction() {
		System.out.println("Hello everyone. I'm " + this.name);
		System.out.println("I'm " + this.age + " years old.");
	}
	
	// static code block
}