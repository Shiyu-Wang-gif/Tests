import java.util.Objects;

public class PM extends Employee {
	// field
	private int yearOfWorking;
	
	// constructor
	public PM() {
		
	}
	
	public PM(int id, String name, int age, Gender gender, int yearOfWorking) {
		super(id, name, age, gender);
		this.yearOfWorking = yearOfWorking;
	}
	
	// setter and getter
	public void setYearOfWorking(int yearOfWorking) {
		this.yearOfWorking = yearOfWorking;
	}
	
	public int getYearOfWorking() {
		return this.yearOfWorking;
	}
	
	// method
	@Override
	public String toString() {
		return super.toString() + ", yearOfWorking " + this.yearOfWorking + "\n";
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(super.hashCode(), this.yearOfWorking);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		
		if (!super.equals(obj)) {
			return false;
		}
		
		PM pm = (PM)obj;
		return this.yearOfWorking == pm.yearOfWorking;
	}
}