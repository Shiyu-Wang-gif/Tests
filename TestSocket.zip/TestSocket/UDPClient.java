import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;

public class UDPClient {
	// main
	public static void main(String[] args) throws Exception {
		DatagramSocket datagramSocket = new DatagramSocket(5000);
		String str = "Hello";
		
		DatagramPacket datagramPacket = new DatagramPacket(str.getBytes(), 0, str.getBytes().length, InetAddress.getByName("127.0.0.1"), 5001);
		datagramSocket.send(datagramPacket);
		
		datagramSocket.close();
	}
	
	// static code block
	static {
		System.out.println("=================================");
		System.out.println("The Client is online!");
		System.out.println("=================================");
	}
}