import java.util.Collection;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.HashSet;
import java.util.TreeSet;

public class TestCollection {
	// method
	public static void separator() {
		System.out.println("================================================================");
	}
	
	public static void show(Collection<Employee> collection) {
		System.out.println("Number of employees: " + collection.size() + "\n" + collection);
	}
	
	// main
	public static void main(String[] args) {
		SE se1 = new SE(130, "Alice", 20, Gender.FEMALE, 93);
		SE se2 = new SE(721, "Bob", 37, Gender.MALE, 63);
		PM pm1 = new PM(1123, "Eve", 25, Gender.FEMALE, 2);
		PM pm2 = new PM(1078, "Bobby", 21, Gender.MALE, 5);
		PM pm3 = new PM(1078, "Bobby", 21, Gender.MALE, 5);
		PM pm4 = new PM(1078, "Dyson", 30, Gender.MALE, 8);
		
		System.out.println("ArrayList");
		separator();
		ArrayList<Employee> arrayList = new ArrayList<Employee>();
		arrayList.add(se1);
		arrayList.add(se2);
		arrayList.add(pm1);
		arrayList.add(pm2);
		show(arrayList);
		arrayList.remove(se2);
		show(arrayList);
		
		separator();
		System.out.println("LinkedList");
		separator();
		LinkedList<Employee> linkedList = new LinkedList<Employee>();
		linkedList.add(se2);
		linkedList.add(pm1);
		linkedList.add(pm2);
		show(linkedList);
		linkedList.remove(0);
		show(linkedList);
		
		separator();
		System.out.println("HashSet");
		separator();
		HashSet<Employee> hashSet = new HashSet<Employee>();
		hashSet.add(se2);
		hashSet.add(pm2);
		hashSet.add(pm3);
		show(hashSet);
		hashSet.remove(pm3);
		show(hashSet);
		
		separator();
		System.out.println("TreeSet");
		separator();
		EmployeeComparator employeeComparator = new EmployeeComparator();
		TreeSet<Employee> treeSet = new TreeSet<Employee>(employeeComparator);
		treeSet.add(se1);
		treeSet.add(pm2);
		treeSet.add(pm4);
		show(treeSet);
		treeSet.remove(pm3);
		show(treeSet);
	}
	
	// static code block
	static {
		separator();
		System.out.println("Test Collection classes");
		separator();
	}
}