import java.net.DatagramSocket;
import java.net.DatagramPacket;

public class UDPServer {
	// main
	public static void main(String[] args) throws Exception {
		DatagramSocket datagramSocket = new DatagramSocket(5001);
		
		byte[] buf = new byte[1024];
		DatagramPacket datagramPacket = new DatagramPacket(buf, buf.length);
		datagramSocket.receive(datagramPacket);
		byte[] data = datagramPacket.getData();
		System.out.println(new String(data));
		System.out.println("data length: " + data.length);
	}
	
	// static code block
	static {
		System.out.println("=================================");
		System.out.println("The Server is online!");
		System.out.println("=================================");
	}
}