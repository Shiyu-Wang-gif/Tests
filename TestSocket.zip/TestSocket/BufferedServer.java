import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;

public class BufferedServer {
	// main
	public static void main(String[] args) throws Exception {
		ServerSocket serverSocket = new ServerSocket(5000);
		Socket socket = serverSocket.accept();
		
		OutputStream outputStream = socket.getOutputStream();
		OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream);
		BufferedWriter bufferedWriter = new BufferedWriter(outputStreamWriter);
		bufferedWriter.write("Hello, I'm your server.");
		bufferedWriter.flush();
		socket.shutdownOutput();
		
		InputStream inputStream = socket.getInputStream();
		InputStreamReader inpuStreamReader = new InputStreamReader(inputStream);
		BufferedReader bufferedReader = new BufferedReader(inpuStreamReader);
		System.out.println("The server received: " + bufferedReader.readLine());
		socket.shutdownInput();
		
		bufferedReader.close();
		inpuStreamReader.close();
		inputStream.close();
		bufferedWriter.close();
		outputStreamWriter.close();
		outputStream.close();
		socket.close();
		serverSocket.close();
	}
	
	// static code block
	static {
		System.out.println("=================================");
		System.out.println("The server is on!");
		System.out.println("=================================");
	}
}