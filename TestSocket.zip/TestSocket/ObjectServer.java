import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;

public class ObjectServer {
	// main
	public static void main(String[] args) throws Exception {
		User user = new User("Shiyu", "wang");
		User RUser;
		boolean flag = false;
		
		ServerSocket serverSocket = new ServerSocket(5000);
		while (!flag) {
			// create socket and streams
			Socket socket = serverSocket.accept();
		
			InputStream inputStream = socket.getInputStream();
			ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
		
			OutputStream outputStream = socket.getOutputStream();
			DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
		
			// login process
			RUser = (User)objectInputStream.readObject();
			System.out.println(RUser.toString());
			flag = RUser.equals(user);
			dataOutputStream.writeBoolean(flag);
			
			socket.shutdownOutput();
			socket.shutdownInput();
		
			// close streams
			dataOutputStream.close();
			outputStream.close();
			objectInputStream.close();
			inputStream.close();
			socket.close();
		}
		serverSocket.close();
		
	}
	
	// static code block
	static {
		System.out.println("============================");
		System.out.println("The server is online.");
		System.out.println("============================");
	}
}