public class Goods {
	// field
	private String name;
	private double price;
	
	// constructor
	public Goods() {
		
	}
	
	public Goods(String name, double price) {
		this.name = name;
		this.price = price;
	}
	
	// setter and getter
	public void setName(String name) {
		this.name = name;
	}
	
	public void setPrice(double price) {
		this.price = price;
	}
	
	public String getName() {
		return this.name;
	}
	
	public double getPrice() {
		return this.price;
	}
	
	// method
	public StringBuffer formatDouble(double num) {
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append(num);
		for (int insertIndex = stringBuffer.indexOf(".") - 3; insertIndex > 0; insertIndex = insertIndex - 3) {
			stringBuffer.insert(insertIndex, ',');
		}
		return stringBuffer;
	}
	
	public StringBuffer show() {
		final int totalLength = 20;
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append(this.name); 
		for (int i = 0; i < totalLength - this.name.length(); i++) {
			stringBuffer.append(' ');
		}
		stringBuffer.append(formatDouble(this.price));
		return stringBuffer;
	}
	
	public StringBuffer totalDue(int qty) {
		StringBuffer stringBuffer = new StringBuffer();
		stringBuffer.append(formatDouble(qty * this.price));
		return stringBuffer;
	}
}