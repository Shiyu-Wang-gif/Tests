public class Centipede extends Monster {
	// field
	
	// constructor
	public Centipede() {
		// super();
	}
	
	public Centipede(String name, int health, int attack) {
		super(name, health, attack);
	}
	
	// setter and getter
	
	// method
	public void move() {
		System.out.println("I'm a centipede so I move straightly");
	}
	
	// static code block
}