public class Main {
    // main
    public static void main(String[] args) {
        Cat[] cats = {new Cat(8, 8), new Cat(5, 5),
                new Cat(1, 1), new Cat(2, 2)};
        Sorter<Cat> sorter = new Sorter<>(cats, new CatWeightComparator());

        sorter.show();
        sorter.sort();
        sorter.show();
    }

    // static code block
    static {
        System.out.println("=====================================");
        System.out.println("Test the Strategy Design Pattern");
        System.out.println("=====================================");
    }
}
