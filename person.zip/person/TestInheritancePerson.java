public class TestInheritancePerson {
	// main
	public static void main(String[] args) {
		Actor actor1 = new Actor("Wang", 25, "male", "MIT", "One day day");
		actor1.selfIntroduction();
		System.out.println("=============================================");
		
		Athlete athlete1 = new Athlete("Mary", 20, "female", "archery", "100 points");
		athlete1.selfIntroduction();
	}
	
	// static code block
	static {
		System.out.println("Test the inheritance of the superclass Person");
		System.out.println("=============================================");
	}
}