import java.util.Objects;

public abstract class Employee implements Comparable<Employee> {
	// field
	private int id;
	private String name;
	private int age;
	private Gender gender;
	
	// constructor
	public Employee() {
		
	}
	
	public Employee(int id, String name, int age, Gender gender) {
		this.id = id;
		this.name = name;
		this.age = age;
		this.gender = gender;
	}
	
	// setter and getter
	public void setId(int id) {
		this.id = id;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	
	public int getId() {
		return this.id;
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getAge() {
		return this.age;
	}
	
	public Gender getGender() {
		return this.gender;
	}
	
	// method
	@Override
	public String toString() {
		return "id " + this.id + ", name " + this.name + ", age " + this.age + ", gender " + this.gender;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(this.id, this.name, this.age, this.gender);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		Employee employee = (Employee)obj;
		return this.id == employee.id && 
		       this.name.equals(employee.name) &&
		       this.age == employee.age &&
		       this.gender == employee.gender;
	}
	
	@Override
	public int compareTo(Employee employee) {
		if (this.id < employee.id) {
			return -1;
		} else if (this.id > employee.id) {
			return 1;
		} else {
			return 0;
		}
	}
}