// package petSystem;

public class Dog extends Pet {
	// field
	private String strain;
	
	// constructor
	public Dog() {
		// super();
	}
	
	public Dog(String name, String strain) {
		super.setName(name);
		this.strain = strain;
	}
	
	public Dog(String name, int health, int intimacy, String strain) {
		super(name, health, intimacy);
		this.strain = strain;
	}
	
	// setter and getter
	public void setStrain(String strain) {
		this.strain = strain;
	}
	
	public String getStrain() {
		return this.strain;
	}
	
	// method
	public void printField() {
		System.out.println("The dog's information:");
		super.printField();
		System.out.println("strain: " + this.strain);
	}
	
	// main
	
	// static code block
}