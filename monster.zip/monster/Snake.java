public class Snake extends Monster {
	// field
	
	// constructor
	public Snake() {
		// super();
	}
	
	public Snake(String name, int health, int attack) {
		super(name, health, attack);
	}
	
	// setter and getter
	
	// method
	public void move() {
		System.out.println("I'm a snake so I move with a curve");
	}
	
	public void addHealth() {
		if (super.getHealth() < 10) {
			super.setHealth(super.getHealth() + 20);
			System.out.println("recover 20 health");
		}
		else {
			System.out.println("health is more than 20, cannot add health");
		}
		
		System.out.println("Current health: " + super.getHealth());
	}
	
	// static code block
}