public class Producer implements Runnable {
	// field
	private Goods goods;
	
	// constructor
	public Producer() {
		
	}
	
	public Producer(Goods goods) {
		this.goods = goods;
	}
	
	// setter and getter
	
	// method
	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			if (i % 2 == 0) {
				this.goods.produce("Apple", "iPhone 12");
			} else {
				this.goods.produce("Huawei", "Mate 40");
			}
		}
	}
}