public class Consumer implements Runnable {
	// field
	private Goods goods;
	
	// constructor
	public Consumer() {
		
	}
	
	public Consumer(Goods goods) {
		this.goods = goods;
	}
	
	// setter and getter
	
	// method
	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			this.goods.consume();
		}
	}
}