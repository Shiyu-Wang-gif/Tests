public class TestCars {
	// main
	public static void main(String[] args) {
		TaxiCar taxiCar1 = new TaxiCar("Honda", "LA1234", "Empire Taxi");
		taxiCar1.start();
		taxiCar1.stop();
		System.out.println("===============================");
		
		FamilyCar familyCar1 = new FamilyCar("Maserati", "NY9999", "Everly");
		familyCar1.start();
		familyCar1.stop();
	}
	
	// static code block
	static {
		System.out.println("Test the inheritance of the Car class");
		System.out.println("=====================================");
	}
}