public class UserInfo {
	// field
	private String userName;
	private String password;
	
	// constructor
	public UserInfo() {
		
	}
	
	public UserInfo(String userName, String password) {
		this.userName = userName;
		this.password = password;
	}
	
	// setter and getter
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getUserName() {
		return this.userName;
	}
	
	public String getPassword() {
		return this.password;
	}
	
	// method
	public boolean loginCheck(String userName, String password) {
		if ( userName.equals(this.userName) && password.equals(this.password) ) {
			return true;
		} else {
			return false;
		}
	}
}