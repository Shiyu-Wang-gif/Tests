public class Monster {
	// field
	private String name;
	private int health;
	private int attack;
	
	// constructor
	public Monster() {
		
	}
	
	public Monster(String name, int health, int attack) {
		this.name = name;
		this.setHealth(health);
		this.setAttack(attack);
	}
	
	// setter and getter
	public void setName(String name) {
		this.name = name;
	}
	
	public void setHealth(int health) {
		if (health >= 0) {
			this.health = health;
		}
		else {
			System.out.println("invalid health input");
		}
	}
	
	public void setAttack(int attack) {
		if (attack >= 0) {
			this.attack = attack;
		}
		else {
			System.out.println("invalid attack input");
		}
	}
	
	public String getName() {
		return this.name;
	}
	
	public int getHealth() {
		return this.health;
	}
	
	public int getAttack() {
		return this.attack;
	}
	
	// method
	public void attacking() {
		System.out.println(this.name + " is attacking!");
		System.out.println("Health: " + this.health);
		System.out.println("Attack: " + this.attack);
	}
	
	public void move() {
		
	}
	
	// static code block
}