public class Actor extends Person {
	// field
	private String university;
	private String representativeWork;
	
	// constructor
	public Actor() {
		// super();
	}
	
	public Actor(String name, int age, String gender, String university, String representativeWork) {
		super(name, age, gender);
		this.university = university;
		this.representativeWork = representativeWork;
	}
	
	// setter and getter
	public void setUniversity(String university) {
		this.university = university;
	}
	
	public void setRepresentativeWork(String representativeWork) {
		this.representativeWork = representativeWork;
	}
	
	public String getUniversity() {
		return this.university;
	}
	
	public String getRepresentativeWork() {
		return this.representativeWork;
	}
	
	// method
	@Override
	public void selfIntroduction() {
		super.selfIntroduction();
		System.out.println("I'm graduated from " + this.university);
		System.out.println("My representative work is " + this.representativeWork);
	}
	
	// static code block
}